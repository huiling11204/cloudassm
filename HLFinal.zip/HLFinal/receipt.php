<?php
session_start();
if (!isset($_SESSION['userLogin'])) {
    header("Location: login-form-2.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Receipt</title>
        <!-- Include your CSS stylesheets and any necessary scripts here -->
    </head>
    <body>
        <!-- Your receipt content here -->
        <div class="container">
            <h1>Receipt</h1>
            <p>This is your receipt content.</p>
            <?php
            // Fetch payment data from the database
            $con = mysqli_connect('database1.c86fi5vvoic1.us-east-1.rds.amazonaws.com', 'admin', 'Abcd1234', 'database1', '3306');
//            $con = mysqli_connect("localhost", "root", "", "liyi");
            if (!$con) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $paymentId = $_SESSION['paymentId'];
            // Example query to fetch payment data (customize as per your table structure)
            $sql = "SELECT * FROM payment WHERE paymentid = ?";  // Assuming you store student ID in the payment table
            $stmt = $con->prepare($sql);
            if ($stmt) {
                $studentID = $_SESSION['userLogin'];  // Assuming you store the user ID in the session
                $stmt->bind_param("s", $paymentId);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Display payment details
                    echo '<div class="container">';
                    echo '<h1>Receipt</h1>';
                    while ($row = $result->fetch_assoc()) {
                        echo '<div>';
                        echo 'Payment ID: ' . $row['paymentid'] . '<br>';
                        echo 'Student ID: ' . $row['studentid'] . '<br>';
                        echo 'Product ID: ' . $row['productid'] . '<br>';
                        echo 'Total Amount: ' . $row['totalamount'] . '<br>';
                        echo 'Product Quantity: ' . $row['productqty'] . '<br>';
                        // Add more fields as needed
                        echo '</div>';
                    }
                    echo '</div>';
                } else {
                    echo 'No payment records found.';
                }

                $stmt->close();
            } else {
                echo 'Error in preparing statement.';
            }

            $con->close();
            ?>

        </div>
    </body>
</html>
