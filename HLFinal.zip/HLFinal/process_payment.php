<?php

session_start();

function generatePaymentID() {
    $con = mysqli_connect('database1.c86fi5vvoic1.us-east-1.rds.amazonaws.com', 'admin', 'Abcd1234', 'database1', '3306');
//    $con = mysqli_connect("localhost", "root", "", "liyi");

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
    $sqlRent = "SELECT * FROM Payment ORDER BY paymentid DESC LIMIT 1";
    $result = mysqli_query($con, $sqlRent);
    $row = mysqli_fetch_assoc($result);
    $lastID = $row['paymentid'];

    $f_ID = null;
    while ($f_ID === null) {
        if ($lastID === null) {
            $f_ID = "P000001";
        } else {
            $nextid = substr($lastID, 1) + 1;
            $f_ID = "P" . sprintf('%06d', $nextid);
        }

        $check_query = "SELECT paymentid FROM payment WHERE paymentid = '$f_ID'";
        $check_result = mysqli_query($con, $check_query);

        if (mysqli_num_rows($check_result) > 0) {
            $f_ID = null; // Payment ID already exists, generate a new one
            $lastID = $f_ID; // Use the new Payment ID as the last ID to generate the next one
        }
    }
    mysqli_free_result($result);
    mysqli_free_result($check_result);

    return $f_ID;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (!isset($_POST['placeorder'])) {
            throw new Exception('Invalid request.');
        }

        $studentID = $_POST['studentid'];
        $products = $_POST['products'];
        $quantities = $_POST['quantities'];
        $prices = $_POST['prices'];
        $orderIds = $_POST['orderid'];
        $con = mysqli_connect('database1.c86fi5vvoic1.us-east-1.rds.amazonaws.com', 'admin', 'Abcd1234', 'database1', '3306');
//        $con = new mysqli("localhost", "root", "", "liyi");
        if ($con->connect_error) {
            die("Connection failed: " . $con->connect_error);
        }

        $con->autocommit(FALSE); // Start transaction

        $sql = 'INSERT INTO payment (paymentid, studentid, productid, totalamount, productqty) VALUES (?, ?, ?, ?, ?)';
        $stmt = $con->prepare($sql);

        // Insert the data into the database
        $success = true;
        for ($i = 0; $i < count($products); $i++) {
            $paymentId = generatePaymentID();
            $product_id = $products[$i];
            $quantity = (int) $quantities[$i];
            $product_price = (float) $prices[$i];
            $total_amount = $product_price * $quantity;
            $stmt->bind_param("sssdi", $paymentId, $studentID, $product_id, $total_amount, $quantity);

            if ($stmt->execute()) {
                $order_id = $orderIds[$i];
                $deleteStmt = $con->prepare("DELETE FROM cart WHERE orderid = ?");
                $deleteStmt->bind_param("s", $order_id);
                $deleteStmt->execute();
                $deleteStmt->close();
            } else {
                $success = false;
                break;
            }
        }

        if ($success) {
            $con->commit(); // Commit transaction
            $_SESSION['success'] = 'Payment was successful! <a href="homepage-2.php" class="alert-link">Continue Shopping</a>';
        } else {
            throw new Exception('Payment failed during execution.');
        }
    } catch (Exception $e) {
        if (isset($con) && $con->errno) {
            $con->rollback(); // Rollback transaction on error
        }
        $_SESSION['error'] = 'Payment failed: ' . $e->getMessage();
    } finally {
        if (isset($con) && $con->errno) {
            $con->close();
        }
    }

    // Only set the success message and redirect after the payment has been processed
    if (isset($_SESSION['success'])) {
        header('Location: payment-2.php');
        exit();
    }
} else {
    $_SESSION['error'] = 'Invalid request method.';
    header('Location: payment-2.php');
    exit();
}
?>
